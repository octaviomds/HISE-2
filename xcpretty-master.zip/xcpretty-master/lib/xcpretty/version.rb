module XCPretty
  VERSION = "0.4.0"
end

